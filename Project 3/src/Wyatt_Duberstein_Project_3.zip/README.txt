How to compile and run this project:

1. While in the directory of the 4 classes (Toy.java, Table.java, Record.java, & Attribute.java) run "javac Toy.java".

2. Run commands using the format "java Toy <command> <arg1> <arg2>"
   Ex: "java Toy create xyz.tb"
   Ex: "java Toy delete 1 xyz.tb"